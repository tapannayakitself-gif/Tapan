# Site → Elementor JSON

URL ya screenshot do, Elementor-importable template JSON milega.

## Setup
```bash
npm install
npx playwright install chromium   # agar chromium alag path pe ho: .env me CHROMIUM_PATH
cp .env.example .env     # GEMINI_API_KEY daalo
npm start                # http://localhost:3000
```
CLI: `node src/cli.js https://example.com out.json`

## Elementor me import
WordPress → Elementor → Templates → Saved Templates → **Import Templates** → JSON choose karo.
Phir kisi page me Add Template → My Templates se insert karo.
Requirement: Elementor ka **Flexbox Container** feature enabled ho (naye versions me default on).

## Kaunsa mode use karein?
**URL mode.** Isme asli HTML/CSS milta hai (exact font, spacing, colors, desktop+tablet+mobile layout). Screenshot mode me Gemini andaza lagata hai, isliye sirf tab use karo jab URL available na ho.

## Output me kya hota hai
- Header/footer/top-bar automatically hata diye jate hain (UI me checkbox, CLI me `KEEP_HEADER_FOOTER=true` se rakh sakte ho).
- Desktop (1440) + tablet (820) + mobile (390) alag extract hote hain, Elementor ke `_tablet` / `_mobile` settings me map hote hain.
- Hero overlay (gradient / ::before), background image, gradient bg, button (icon hata ke text), Font Awesome icons, sliders (cards ban jate hain), cards/pills ka bg+border+shadow.
- Forms, tables, svg, video HTML widget me jate hain (Elementor Free me form widget nahi hota).

## Import ke baad
Page Settings -> Page Layout -> **Elementor Canvas** (ya Full Width) + **Hide Title** on karo.

## Pipeline
| Step | File | Kya karta hai |
|---|---|---|
| 1 | `src/extract.js` | Playwright se desktop (1440) + mobile (390) render, DOM + computed styles nikalta hai |
| 2 | `src/convert.js` | Deterministic converter: h1-h6→Heading, text→Text Editor, img→Image, button-like a→Button, div→Container |
| 3 | `src/gemini.js` | `refineNode`: slider/accordion/tabs ko native widget me badalne ki koshish. `screenshotToElementor`: screenshot mode |
| 4 | `src/validate.js` | Ids unique, elType/widgetType valid, tree sanitize |

URL mode me Gemini ke bina bhi poora kaam hota hai (`USE_GEMINI_REFINE=false`).
Jo block convert nahi ho sakta (svg, form, table, slider) wo **HTML widget** me computed styles inline karke jata hai, taaki dikhne me same rahe.

## Known limitations
- Pixel-perfect nahi: ~80-90% simple/medium pages pe.
- Animations, JS sliders, sticky/parallax, hover effects: copy nahi hote.
- Gradients backgrounds skip hote hain (sirf solid color / image).
- Images remote URLs se link hoti hain; Elementor import ke baad media library me sideload nahi hoti.
- Slider/carousel ki saari slides cards ban jati hain (slider chalta nahi). Tablet/mobile pe jo slides carousel me kati hui thi wo hide ho jati hain.
- Accordion/tabs ke band panels ka content nahi aata (sirf jo visible hai).
- Absolute-positioned badges flow me aa jate hain (jagah thodi alag ho sakti hai).
- Custom/paid fonts site pe hi load hote hain; Elementor me font family ka naam set hota hai, file nahi aati.
- Screenshot mode sirf approximate hai. Bahut lambe page ko sections me crop karke bhejo.
- Login-protected ya bot-protected pages (Cloudflare) fetch nahi honge.
- Sirf apni site / jiski permission ho usi ke liye use karo (copyright).

## Production tips
- Public deploy karo to queue (BullMQ) + rate limit + auth lagao.
- SSRF guard basic hai (`server.js`); production me DNS-rebinding/redirect checks bhi add karo.
