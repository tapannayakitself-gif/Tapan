import { GoogleGenAI } from '@google/genai';
import { sanitizeElements, WIDGETS } from './validate.js';

const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
let _ai;
const client = () => {
  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY set nahi hai (.env check karo)');
  return (_ai ??= new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }));
};

const parseJson = (text) => {
  const t = (text || '').replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  return JSON.parse(t);
};

const CHEATSHEET = `
ELEMENTOR FLEXBOX JSON RULES
- Container: {"id":"a1b2c3d","elType":"container","isInner":false,"settings":{...},"elements":[...]}
  settings: content_width:"full", flex_direction:"row"|"column", flex_wrap:"wrap", justify_content:"flex-start|center|flex-end|space-between",
  align_items:"flex-start|center|flex-end|stretch", flex_gap:{"column":"20","row":"20","isLinked":true,"unit":"px","size":20},
  padding:{"unit":"px","top":"60","right":"20","bottom":"60","left":"20","isLinked":false},
  background_background:"classic", background_color:"#ffffff", background_image:{"url":"...","id":""}, background_size:"cover", background_position:"center center",
  width:{"unit":"%","size":50,"sizes":[]}, min_height:{"unit":"px","size":500,"sizes":[]},
  border_radius:{"unit":"px","top":"8","right":"8","bottom":"8","left":"8","isLinked":true}
  Nested containers use "isInner": true. Mobile variants use the suffix _mobile (e.g. flex_direction_mobile:"column").
- Widget: {"id":"...","elType":"widget","widgetType":"heading","settings":{...},"elements":[]}
  heading: title, header_size(h1-h6), align, title_color, typography_typography:"custom", typography_font_family, typography_font_size:{"unit":"px","size":40,"sizes":[]}, typography_font_weight:"700"
  text-editor: editor:"<p>..</p>", text_color, align, typography_* (same keys)
  button: text, link:{"url":"#","is_external":"","nofollow":""}, button_text_color, background_color, text_padding, border_radius
  image: image:{"url":"https://...","id":""}, image_size:"full", width:{"unit":"px","size":400,"sizes":[]}
  icon-box / image-box / icon-list / accordion / tabs / counter / testimonial / divider / spacer / html are also allowed.
`;

const SCREENSHOT_SYSTEM = `You convert website screenshots into Elementor template JSON (flexbox containers).
Output ONLY valid JSON: {"content":[ ...top-level containers... ]}. No markdown, no commentary.
Rules:
- One top-level container per visual section (header, hero, features, ... footer), content_width "full".
- Reproduce ALL visible text exactly. Estimate colors (hex), font sizes (px), paddings and gaps carefully from the image.
- Use row containers with percentage widths for columns; stack on mobile via flex_direction_mobile:"column".
- If an image is needed and its URL is unknown use https://placehold.co/WIDTHxHEIGHT.
- Only use these widgetType values: ${[...WIDGETS].join(', ')}.
${CHEATSHEET}`;

async function generateJson(system, parts, { retries = 2 } = {}) {
  const ai = client();
  const contents = [{ role: 'user', parts }];
  let lastErr;
  for (let i = 0; i <= retries; i++) {
    const res = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: { systemInstruction: system, responseMimeType: 'application/json', temperature: 0.2, maxOutputTokens: 32768 },
    });
    const text = res.text;
    try {
      const json = parseJson(text);
      return json;
    } catch (e) {
      lastErr = e;
      contents.push({ role: 'model', parts: [{ text: text || '' }] });
      contents.push({ role: 'user', parts: [{ text: `Your output was not valid JSON (${e.message}). Return the complete corrected JSON only.` }] });
    }
  }
  throw new Error('Gemini valid JSON nahi de paya: ' + lastErr?.message);
}

/** Screenshot mode: image -> Elementor content[] */
export async function screenshotToElementor(buffer, mimeType = 'image/png') {
  const json = await generateJson(SCREENSHOT_SYSTEM, [
    { inlineData: { mimeType, data: buffer.toString('base64') } },
    { text: 'Convert this page screenshot into Elementor template JSON.' },
  ]);
  const list = Array.isArray(json) ? json : json.content;
  const { elements, errors } = sanitizeElements(list, false);
  if (!elements.length) throw new Error('Gemini se usable elements nahi mile: ' + errors.join('; '));
  return { content: elements, warnings: ['Screenshot mode approximate hai - exact result ke liye URL mode use karo.', ...errors] };
}

const REFINE_SYSTEM = `You convert one interactive HTML block (slider, accordion, tabs, FAQ ...) into ONE native Elementor widget JSON.
Output ONLY JSON: {"element": {...}} or {"element": null} if no native widget fits well.
Allowed widgetType: accordion, tabs, toggle, image-carousel, icon-box, image-box, counter, testimonial, icon-list.
Examples of settings:
- accordion/toggle: {"tabs":[{"_id":"a1b2c3d","tab_title":"Question","tab_content":"<p>Answer</p>"}]}
- tabs: {"tabs":[{"_id":"a1b2c3d","tab_title":"Tab 1","tab_content":"<p>Content</p>"}]}
- image-carousel: {"carousel":[{"id":"","url":"https://..."}],"slides_to_show":"3"}
- icon-box: {"title_text":"Title","description_text":"Text"}
Keep all visible text exactly.`;

/** URL mode fallback: complex block -> native widget (ya null) */
export async function refineNode(node) {
  const json = await generateJson(
    REFINE_SYSTEM,
    [{ text: `Block type hint: ${node.pattern}\nHTML:\n${(node.plainHtml || node.html).slice(0, 12000)}` }],
    { retries: 1 },
  );
  if (!json?.element) return null;
  const { elements } = sanitizeElements([json.element], true);
  const el = elements[0];
  if (!el || el.elType !== 'widget' || el.widgetType === 'html') return null;
  return el;
}
