import 'dotenv/config';
import fs from 'node:fs/promises';
import { extractPage } from './extract.js';
import { convertPage } from './convert.js';
import { refineNode } from './gemini.js';
import { buildTemplate } from './validate.js';

const [url, out = 'template.json'] = process.argv.slice(2);
if (!url) { console.error('Usage: node src/cli.js <url> [out.json]'); process.exit(1); }

const refine = process.env.USE_GEMINI_REFINE === 'true' && process.env.GEMINI_API_KEY ? refineNode : null;
const extracted = await extractPage(url, { patterns: !!refine });
const { content, stats, warnings } = await convertPage(extracted, { refine, skipChrome: process.env.KEEP_HEADER_FOOTER !== 'true' });
await fs.writeFile(out, JSON.stringify(buildTemplate(content, extracted.title || 'Imported Page'), null, 2));
console.log('Saved', out, stats);
if (warnings.length) console.log('Warnings:\n- ' + warnings.join('\n- '));
