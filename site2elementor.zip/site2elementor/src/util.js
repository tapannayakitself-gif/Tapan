import { randomBytes } from 'node:crypto';

export const uid = () => randomBytes(4).toString('hex').slice(0, 7);
export const num = (v) => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};
export const r2 = (n) => Math.round(n * 100) / 100;
export const px = (n) => ({ unit: 'px', size: r2(n), sizes: [] });
export const pct = (n) => ({ unit: '%', size: r2(n), sizes: [] });
export const dim = (t, r, b, l) => ({
  unit: 'px',
  top: String(r2(t)),
  right: String(r2(r)),
  bottom: String(r2(b)),
  left: String(r2(l)),
  isLinked: t === r && r === b && b === l,
});
export const clean = (o) =>
  Object.fromEntries(Object.entries(o).filter(([, v]) => v !== null && v !== undefined && v !== ''));

// "rgb(1, 2, 3)" / "rgba(1 2 3 / .5)" -> "#010203" / "rgba(1,2,3,0.5)" ; transparent -> null
export function color(c) {
  if (!c) return null;
  const m = c.match(/rgba?\(([^)]+)\)/);
  if (!m) return c === 'transparent' ? null : c;
  const [r, g, b, a = 1] = m[1].split(/[,\s/]+/).filter(Boolean).map(Number);
  if (a === 0) return null;
  if (a >= 1) return '#' + [r, g, b].map((x) => Math.round(x).toString(16).padStart(2, '0')).join('');
  return `rgba(${r},${g},${b},${a})`;
}

export const median = (arr) => {
  if (!arr.length) return 0;
  const a = [...arr].sort((x, y) => x - y);
  return a[Math.floor(a.length / 2)];
};
