import { uid } from './util.js';

export const WIDGETS = new Set([
  'heading', 'text-editor', 'image', 'button', 'divider', 'spacer', 'icon', 'icon-box',
  'image-box', 'icon-list', 'html', 'video', 'accordion', 'tabs', 'toggle', 'counter',
  'testimonial', 'star-rating', 'social-icons', 'progress', 'google_maps', 'image-carousel',
]);

/**
 * Elementor tree ko sanitize karta hai: unique ids, valid elType/widgetType, isInner flag.
 * Returns { elements, errors }.
 */
export function sanitizeElements(list, inner = false) {
  const errors = [];
  const fix = (el, isInner, path) => {
    if (!el || typeof el !== 'object') {
      errors.push(`${path}: object nahi hai`);
      return null;
    }
    const settings =
      el.settings && typeof el.settings === 'object' && !Array.isArray(el.settings) ? el.settings : {};
    if (el.elType === 'container') {
      const kids = (Array.isArray(el.elements) ? el.elements : [])
        .map((c, i) => fix(c, true, `${path}.elements[${i}]`))
        .filter(Boolean);
      return { id: uid(), elType: 'container', isInner, settings, elements: kids };
    }
    if (el.elType === 'widget') {
      if (!WIDGETS.has(el.widgetType)) {
        errors.push(`${path}: unknown widgetType "${el.widgetType}"`);
        return null;
      }
      return { id: uid(), elType: 'widget', widgetType: el.widgetType, settings, elements: [] };
    }
    errors.push(`${path}: unknown elType "${el.elType}"`);
    return null;
  };
  const elements = (Array.isArray(list) ? list : [])
    .map((e, i) => fix(e, inner, `content[${i}]`))
    .filter(Boolean);
  return { elements, errors };
}

export function buildTemplate(content, title = 'Imported Page') {
  return { version: '0.4', title, type: 'page', content, page_settings: [], metadata: [] };
}
