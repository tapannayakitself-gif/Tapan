import { chromium } from 'playwright';

export const STYLE_KEYS = [
  'display', 'flexDirection', 'flexWrap', 'justifyContent', 'alignItems', 'columnGap', 'rowGap',
  'position', 'color', 'backgroundColor', 'backgroundImage', 'backgroundSize', 'backgroundPosition',
  'backgroundRepeat', 'fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'lineHeight',
  'letterSpacing', 'textAlign', 'textTransform', 'paddingTop', 'paddingRight', 'paddingBottom',
  'paddingLeft', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
  'borderTopColor', 'borderBottomColor', 'borderTopLeftRadius', 'borderTopRightRadius',
  'borderBottomRightRadius', 'borderBottomLeftRadius', 'boxShadow', 'minHeight', 'maxWidth',
  'objectFit', 'listStyleType', 'opacity',
];

// HTML widget fallback: computed styles inline (site ki CSS ke bina bhi same dikhe)
export const INLINE_KEEP = [
  'display', 'flexDirection', 'flexWrap', 'justifyContent', 'alignItems', 'columnGap', 'rowGap',
  'position', 'top', 'left', 'right', 'bottom', 'color', 'backgroundColor', 'backgroundImage',
  'backgroundSize', 'backgroundPosition', 'backgroundRepeat', 'fontFamily', 'fontSize', 'fontWeight',
  'fontStyle', 'lineHeight', 'letterSpacing', 'textAlign', 'textTransform', 'textDecorationLine',
  'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'marginTop', 'marginRight',
  'marginBottom', 'marginLeft', 'borderTopWidth', 'borderTopStyle', 'borderTopColor',
  'borderRightWidth', 'borderRightStyle', 'borderRightColor', 'borderBottomWidth',
  'borderBottomStyle', 'borderBottomColor', 'borderLeftWidth', 'borderLeftStyle', 'borderLeftColor',
  'borderTopLeftRadius', 'borderTopRightRadius', 'borderBottomRightRadius', 'borderBottomLeftRadius',
  'boxShadow', 'width', 'height', 'maxWidth', 'objectFit', 'opacity', 'overflow', 'fill', 'stroke',
  'strokeWidth', 'transform', 'zIndex', 'listStyleType',
];

/* ---------- Browser ke andar chalne wala function (serialize hota hai, closure use nahi kar sakta) ---------- */
function pageFn({ STYLE_KEYS, INLINE_KEEP, PATTERNS }) {
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'LINK', 'META', 'TEMPLATE', 'HEAD', 'TITLE', 'BR', 'WBR', 'SOURCE', 'TRACK', 'PARAM']);
  const INLINE = new Set(['A', 'SPAN', 'STRONG', 'EM', 'B', 'I', 'SMALL', 'U', 'SUB', 'SUP', 'CODE', 'MARK', 'S', 'DEL', 'INS', 'ABBR', 'CITE', 'Q', 'TIME', 'LABEL', 'FONT', 'BR', 'WBR']);
  const RAW = new Set(['SVG', 'VIDEO', 'IFRAME', 'CANVAS', 'FORM', 'TABLE', 'SELECT', 'INPUT', 'TEXTAREA', 'OBJECT', 'EMBED', 'AUDIO']);
  const MEDIA = new Set(['IMG', 'VIDEO', 'IFRAME', 'CANVAS', 'AUDIO', 'OBJECT', 'EMBED', 'SVG']);
  const BTN_OK = new Set(['IMG', 'I', 'SPAN', 'STRONG', 'EM', 'B', 'SMALL', 'BR', 'PICTURE', 'SOURCE']);
  const PATTERN = /(^|[\s_-])(accordion|tabs?|faq)([\s_-]|$)/i;
  const kebab = (k) => k.replace(/[A-Z]/g, (m) => '-' + m.toLowerCase());
  const esc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  document.querySelectorAll('*').forEach((e, i) => e.setAttribute('data-cid', String(i)));

  const pick = (cs) => { const o = {}; for (const k of STYLE_KEYS) o[k] = cs[k]; return o; };
  const hasText = (el) => (el.textContent || '').trim().length > 0;

  // Font Awesome icon -> "fas fa-bolt"
  const NOT_NAME = new Set(['fa-solid', 'fa-regular', 'fa-brands', 'fa-light', 'fa-fw', 'fa-lg', 'fa-xs', 'fa-sm', 'fa-xl', 'fa-2x', 'fa-3x', 'fa-4x', 'fa-5x', 'fa-spin', 'fa-pulse', 'fa-border']);
  function iconOf(el) {
    const tag = el.tagName.toUpperCase();
    if ((tag !== 'I' && tag !== 'SPAN') || hasText(el)) return null;
    const cls = (el.getAttribute('class') || '').split(/\s+/);
    if (!cls.some((c) => ['fa', 'fas', 'far', 'fab', 'fal', 'fa-solid', 'fa-regular', 'fa-brands'].includes(c))) return null;
    const name = cls.find((c) => c.startsWith('fa-') && !NOT_NAME.has(c) && !/^fa-\d/.test(c));
    if (!name) return null;
    const prefix = cls.includes('fab') || cls.includes('fa-brands') ? 'fab' : cls.includes('far') || cls.includes('fa-regular') ? 'far' : 'fas';
    return prefix + ' ' + name;
  }

  function inlineOk(c) {
    const cs = getComputedStyle(c);
    if (cs.display === 'none') return true;
    if (iconOf(c)) return false;
    if (!INLINE.has(c.tagName.toUpperCase())) return false;
    if (!(cs.display.startsWith('inline') || cs.display === 'contents')) return false;
    return [...c.children].every(inlineOk);
  }
  function isInlineOnly(el) {
    if (!hasText(el)) return false;
    for (const c of el.childNodes) {
      if (c.nodeType === 3 || c.nodeType === 8) continue;
      if (c.nodeType !== 1 || !inlineOk(c)) return false;
    }
    return true;
  }

  function cleanClone(el) {
    const clone = el.cloneNode(true);
    const origs = [el, ...el.querySelectorAll('*')];
    const clones = [clone, ...clone.querySelectorAll('*')];
    const root = getComputedStyle(el);
    origs.forEach((o, i) => {
      const c = clones[i];
      if (!c) return;
      const cs = getComputedStyle(o);
      if (i > 0 && cs.display === 'none') { c.setAttribute('data-rm', '1'); return; }
      const st = [];
      if (i > 0) {
        if (cs.color !== root.color) st.push('color:' + cs.color);
        if (cs.fontWeight !== root.fontWeight) st.push('font-weight:' + cs.fontWeight);
        if (cs.fontStyle !== root.fontStyle) st.push('font-style:' + cs.fontStyle);
        if (cs.fontSize !== root.fontSize) st.push('font-size:' + cs.fontSize);
        if (cs.textDecorationLine !== root.textDecorationLine) st.push('text-decoration:' + cs.textDecorationLine);
      }
      const href = o.tagName === 'A' ? o.href : null;
      for (const a of [...c.attributes]) c.removeAttribute(a.name);
      if (href) c.setAttribute('href', href);
      if (st.length) c.setAttribute('style', st.join(';'));
    });
    clone.querySelectorAll('[data-rm]').forEach((x) => x.remove());
    return clone;
  }

  // complex block: computed styles inline, lekin width/height hata ke taaki responsive rahe
  function inlineHtml(el) {
    const clone = el.cloneNode(true);
    const origs = [el, ...el.querySelectorAll('*')];
    const clones = [clone, ...clone.querySelectorAll('*')];
    origs.forEach((o, i) => {
      const c = clones[i];
      if (!c) return;
      const cs = getComputedStyle(o);
      const tagU = o.tagName.toUpperCase();
      const inSvg = !!o.closest('svg');
      const keepSize = inSvg || MEDIA.has(tagU);
      const st = [];
      for (const k of INLINE_KEEP) {
        if (!keepSize && (k === 'width' || k === 'height')) continue;
        // root element: position/offsets/margins hata do, warna HTML widget ke andar jagah se hat jata hai
        if (i === 0 && ['position', 'top', 'left', 'right', 'bottom', 'marginTop', 'marginRight', 'marginBottom', 'marginLeft', 'transform'].includes(k)) continue;
        const v = cs[k];
        if (!v || v === 'auto' || v === 'normal') continue;
        st.push(kebab(k) + ':' + v);
      }
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(tagU)) st.push('width:100%', 'box-sizing:border-box');
      else if (i === 0 && !MEDIA.has(tagU)) st.push('width:100%', 'max-width:100%');
      else if (tagU === 'IMG' || tagU === 'SVG' || tagU === 'svg') st.push('max-width:100%');
      for (const a of [...c.attributes]) {
        const n = a.name;
        if (n === 'class' || n === 'style' || n.startsWith('data-') || n.startsWith('on') || ['srcset', 'sizes', 'loading'].includes(n)) c.removeAttribute(n);
      }
      if (tagU === 'IMG') c.setAttribute('src', o.currentSrc || o.src);
      if (tagU === 'A') c.setAttribute('href', o.href);
      if (tagU === 'IFRAME' && o.src) c.setAttribute('src', o.src);
      c.setAttribute('style', st.join(';'));
    });
    clone.querySelectorAll('script,noscript').forEach((x) => x.remove());
    clone.querySelectorAll('use').forEach((u) => {
      const h = u.getAttribute('href') || u.getAttribute('xlink:href');
      if (h && h.startsWith('#')) {
        let ref = null;
        try { ref = document.getElementById(h.slice(1)); } catch {}
        if (ref) {
          const svg = u.closest('svg');
          if (svg && !svg.getAttribute('viewBox') && ref.getAttribute('viewBox')) svg.setAttribute('viewBox', ref.getAttribute('viewBox'));
          u.outerHTML = '<g>' + ref.innerHTML + '</g>';
        }
      }
    });
    return clone.outerHTML;
  }

  // ::before / ::after se bane overlays (hero ke upar dark layer wagairah)
  function pseudoOverlays(el, r) {
    const out = [];
    for (const ps of ['::before', '::after']) {
      const p = getComputedStyle(el, ps);
      if (!p || p.content === 'none' || p.content === 'normal' || p.position !== 'absolute') continue;
      const bi = p.backgroundImage, bc = p.backgroundColor;
      if (bi && bi.includes('url(')) continue;
      const hasBg = (bc && bc !== 'rgba(0, 0, 0, 0)' && bc !== 'transparent') || (bi && bi !== 'none');
      if (!hasBg) continue;
      if (parseFloat(p.width) >= r.width * 0.9 && parseFloat(p.height) >= r.height * 0.9) {
        out.push({ backgroundColor: bc, backgroundImage: bi, opacity: p.opacity });
      }
    }
    return out;
  }

  function collectKids(el, depth, out, parentNode, clip) {
    for (const c of el.childNodes) {
      if (c.nodeType === 3) {
        const t = c.textContent.replace(/\s+/g, ' ').trim();
        if (t) out.push({ cid: null, tag: 'span', virtual: true, rect: parentNode.rect, s: parentNode.s, html: esc(t), children: [] });
      } else if (c.nodeType === 1) {
        if (!SKIP.has(c.tagName.toUpperCase()) && getComputedStyle(c).display === 'contents') collectKids(c, depth, out, parentNode, clip);
        else { const ch = walk(c, depth + 1, clip); if (ch) out.push(ch); }
      }
    }
  }

  function walk(el, depth, clip) {
    const tag = el.tagName.toUpperCase();
    if (SKIP.has(tag)) return null;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return null;
    const r = el.getBoundingClientRect();
    if (tag !== 'BODY' && (r.width < 1 || r.height < 1)) return null;
    if (tag !== 'BODY' && (r.left >= innerWidth + 5 || r.right <= -5)) return null; // off-screen slides/menus
    if (tag !== 'BODY' && clip && (r.left >= clip.r - 1 || r.right <= clip.l + 1)) return null; // overflow:hidden se kate hue slides
    let childClip = clip;
    if (['hidden', 'clip', 'auto', 'scroll'].includes(cs.overflowX)) {
      childClip = clip ? { l: Math.max(clip.l, r.left), r: Math.min(clip.r, r.right) } : { l: r.left, r: r.right };
    }

    const node = {
      cid: Number(el.getAttribute('data-cid')),
      tag: tag.toLowerCase(),
      cls: (el.getAttribute('class') || '').slice(0, 200),
      id: el.id || '',
      role: el.getAttribute('role') || '',
      rect: { x: r.left + scrollX, y: r.top + scrollY, w: r.width, h: r.height },
      s: pick(cs),
      children: [],
    };
    if (tag === 'A') node.href = el.href;
    if (tag === 'IMG') {
      node.src = el.currentSrc || el.src;
      node.alt = el.alt || '';
      node.nw = el.naturalWidth || 0;
      node.nh = el.naturalHeight || 0;
      return node;
    }
    const icon = iconOf(el);
    if (icon) { node.icon = icon; return node; }

    if (RAW.has(tag)) {
      node.raw = true;
      node.html = inlineHtml(el);
      return node;
    }
    const cls = el.getAttribute('class') || '';
    if (PATTERNS && depth > 1 && el.children.length && r.height < 1600 && !['BODY', 'MAIN', 'HEADER', 'FOOTER'].includes(tag) && PATTERN.test(cls)) {
      node.raw = true;
      node.pattern = (cls.match(PATTERN) || [])[2]?.toLowerCase() || 'widget';
      node.html = inlineHtml(el);
      node.plainHtml = el.outerHTML.slice(0, 12000);
      return node;
    }

    // icon + text wala button/link -> sirf text ka button
    if ((tag === 'A' || tag === 'BUTTON') && hasText(el) && el.querySelector('svg,img,i')) {
      const ok = [...el.querySelectorAll('*')].every((x) => BTN_OK.has(x.tagName.toUpperCase()) || x.closest('svg'));
      const t = (el.innerText || '').replace(/\s+/g, ' ').trim();
      if (ok && t && t.length < 80) { node.html = esc(t); node.btn = true; return node; }
    }

    if (tag === 'UL' || tag === 'OL') {
      const lis = [...el.querySelectorAll('li')];
      if (lis.length && cs.listStyleType !== 'none' && lis.every((l) => getComputedStyle(l).display === 'list-item') && !el.querySelector('div,section,img,svg,h1,h2,h3,h4,h5,h6,button,i')) {
        const cl = cleanClone(el);
        node.html = cl.innerHTML;
        node.wrapHtml = cl.outerHTML;
        return node;
      }
    }
    if (isInlineOnly(el)) {
      node.html = cleanClone(el).innerHTML;
      return node;
    }

    const ov = pseudoOverlays(el, r);
    if (ov.length) node.overlays = ov;
    collectKids(el, depth, node.children, node, childClip);
    return node;
  }

  return { tree: walk(document.body, 0, null), title: document.title, viewport: innerWidth };
}

async function autoScroll(page) {
  await page.evaluate(async () => {
    await new Promise((resolve) => {
      let y = 0;
      const step = 600;
      const t = setInterval(() => {
        window.scrollBy(0, step);
        y += step;
        if (y >= document.body.scrollHeight + 600 || y > 30000) { clearInterval(t); window.scrollTo(0, 0); resolve(); }
      }, 120);
    });
  });
  await page.waitForTimeout(600);
}

const launchOpts = () => {
  const exe = process.env.CHROMIUM_PATH;
  const extra = (process.env.CHROMIUM_ARGS || '').split(' ').filter(Boolean);
  return exe ? { executablePath: exe, args: ['--no-sandbox', ...extra] } : {};
};

export async function extractPage(url, { desktop = 1440, tablet = 820, mobile = 390, patterns = false } = {}) {
  const browser = await chromium.launch(launchOpts());
  try {
    const out = {};
    for (const [name, width] of [['desktop', desktop], ['tablet', tablet], ['mobile', mobile]]) {
      const ctx = await browser.newContext({
        viewport: { width, height: 900 },
        isMobile: name === 'mobile',
        deviceScaleFactor: 1,
      });
      const page = await ctx.newPage();
      try {
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
        await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
        await autoScroll(page);
        await page.addStyleTag({ content: '*{animation:none!important;transition:none!important}' });
        const res = await page.evaluate(pageFn, { STYLE_KEYS, INLINE_KEEP, PATTERNS: patterns });
        out[name] = res.tree;
        if (name === 'desktop') out.title = res.title;
      } catch (e) {
        if (name === 'desktop') throw e;
        out[name + 'Error'] = e.message;
      } finally {
        await ctx.close();
      }
    }
    return out;
  } finally {
    await browser.close();
  }
}
