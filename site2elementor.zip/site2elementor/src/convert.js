import { uid, num, r2, px, pct, dim, clean, color, median } from './util.js';
import { sanitizeElements } from './validate.js';

const BPS = ['tablet', 'mobile'];

/* ================= small helpers ================= */
const GENERIC_FONTS = new Set(['system-ui', 'sans-serif', 'serif', 'monospace', '-apple-system', 'blinkmacsystemfont', 'ui-sans-serif']);
const firstFont = (ff = '') => {
  const f = ff.split(',')[0].replace(/["']/g, '').trim();
  return GENERIC_FONTS.has(f.toLowerCase()) ? '' : f;
};
const align = (s) => ({ start: 'left', left: 'left', end: 'right', right: 'right', center: 'center', justify: 'justify' }[s.textAlign] || 'left');
const borders = (s) => [num(s.borderTopWidth), num(s.borderRightWidth), num(s.borderBottomWidth), num(s.borderLeftWidth)];
const paddings = (s) => [num(s.paddingTop), num(s.paddingRight), num(s.paddingBottom), num(s.paddingLeft)];
const radius = (v = '0', rect) => (String(v).includes('%') ? (parseFloat(v) / 100) * Math.min(rect.w, rect.h) : num(v));
const radii = (s, rect) => [radius(s.borderTopLeftRadius, rect), radius(s.borderTopRightRadius, rect), radius(s.borderBottomRightRadius, rect), radius(s.borderBottomLeftRadius, rect)];
const plain = (html) => html.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').trim();
// % width: thoda kam rakho taaki rounding ki wajah se row wrap na ho
const safe = (w) => (w >= 99.8 ? 100 : Math.max(1, Math.floor((w - 0.2) * 100) / 100));
const widget = (widgetType, settings) => ({ id: uid(), elType: 'widget', widgetType, settings: clean(settings), elements: [] });

function splitTop(str) {
  const out = [];
  let d = 0, cur = '';
  for (const ch of str) {
    if (ch === '(') d++;
    if (ch === ')') d--;
    if (ch === ',' && d === 0) { out.push(cur.trim()); cur = ''; } else cur += ch;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
function bgLayers(s) {
  const v = s.backgroundImage || 'none';
  if (v === 'none') return { urls: [], grads: [] };
  const layers = splitTop(v);
  return {
    urls: layers.filter((l) => l.startsWith('url(')).map((l) => (/url\(["']?(.*?)["']?\)/.exec(l) || [])[1]).filter(Boolean),
    grads: layers.filter((l) => /^linear-gradient\(/.test(l)),
  };
}
const keepColor = (c) => color(c) || 'rgba(0,0,0,0)';
function parseGradient(g) {
  const inner = g.slice(g.indexOf('(') + 1, g.lastIndexOf(')'));
  const parts = splitTop(inner);
  let angle = 180, i = 0;
  const first = parts[0] || '';
  const dm = /^(-?[\d.]+)deg$/.exec(first);
  if (dm) { angle = +dm[1]; i = 1; }
  else if (/^to /.test(first)) {
    const map = { 'to top': 0, 'to right': 90, 'to bottom': 180, 'to left': 270, 'to top right': 45, 'to right top': 45, 'to bottom right': 135, 'to right bottom': 135, 'to bottom left': 225, 'to left bottom': 225, 'to top left': 315, 'to left top': 315 };
    angle = map[first] ?? 180; i = 1;
  }
  const stops = parts.slice(i).map((p) => {
    const m = /^(.*?)(?:\s+(-?[\d.]+)%)?$/.exec(p);
    return { c: keepColor(m[1].trim()), p: m[2] !== undefined ? +m[2] : null };
  });
  if (stops.length < 2) return null;
  const a = stops[0], b = stops[stops.length - 1];
  return { angle, c1: a.c, p1: a.p ?? 0, c2: b.c, p2: b.p ?? 100 };
}
const gradSet = (prefix, g) => ({
  [`${prefix}_background`]: 'gradient',
  [`${prefix}_color`]: g.c1,
  [`${prefix}_color_stop`]: { unit: '%', size: g.p1, sizes: [] },
  [`${prefix}_color_b`]: g.c2,
  [`${prefix}_color_b_stop`]: { unit: '%', size: g.p2, sizes: [] },
  [`${prefix}_gradient_type`]: 'linear',
  [`${prefix}_gradient_angle`]: { unit: 'deg', size: g.angle, sizes: [] },
});
// overlay layer -> Elementor background_overlay_* (opacity 1 explicit: Elementor ka default 0.5 hota hai)
function overlaySet(l) {
  const op = { unit: 'px', size: num(l.opacity ?? 1) || 1, sizes: [] };
  const { grads } = bgLayers({ backgroundImage: l.backgroundImage });
  if (grads.length) {
    const g = parseGradient(grads[0]);
    if (g) return { ...gradSet('background_overlay', g), background_overlay_opacity: op };
  }
  const c = color(l.backgroundColor);
  if (c) return { background_overlay_background: 'classic', background_overlay_color: c, background_overlay_opacity: op };
  return null;
}

/* ================= tree utils ================= */
function walkTree(n, fn) { fn(n); n.children.forEach((c) => walkTree(c, fn)); }
function indexTree(n, map) { walkTree(n, (x) => { if (x.cid != null) map.set(x.cid, x); }); }
const hasContent = (n) => !!(n.raw || n.tag === 'img' || n.icon || n.html !== undefined || n.children.some(hasContent));
const textOf = (n) => (n.html || '') + ' ' + n.children.map(textOf).join(' ');
const hasTag = (n, re) => re.test(n.tag) || n.children.some((c) => hasTag(c, re));
const flow = (n) => n.children.filter((c) => c.s.position !== 'absolute' && c.s.position !== 'fixed');

function layoutDir(n) {
  const s = n.s;
  if (s.display.includes('flex')) return s.flexDirection || 'row';
  if (s.display.includes('grid')) return 'row';
  const k = flow(n);
  if (k.length > 1 && k.every((c) => Math.abs(c.rect.y - k[0].rect.y) < 6 && c.rect.x >= k[0].rect.x - 1)) return 'row';
  return 'column';
}

const BTN_CLASS = /(^|[\s_-])(btn|button|cta)([\s_-]|$)/i;
function looksLikeButton(n) {
  if (n.btn || n.tag === 'button') return true;
  if (n.tag !== 'a' || n.html === undefined || plain(n.html).length >= 80) return false;
  const s = n.s;
  const box = color(s.backgroundColor) || borders(s).some(Boolean);
  const [pt, pr, pb, pl] = paddings(s);
  return !!((box && pt + pb >= 6 && pl + pr >= 12) || BTN_CLASS.test(n.cls || ''));
}

function classify(n) {
  if (n.raw) return 'html';
  if (n.icon) return 'icon';
  if (n.tag === 'img') return 'image';
  if (n.html !== undefined) {
    if (looksLikeButton(n)) return 'button';
    if (/^h[1-6]$/.test(n.tag)) return 'heading';
    if (!n.wrapHtml && num(n.s.fontSize) >= 28 && !/<a\b/.test(n.html) && n.html.length < 140) return 'heading';
    return 'text';
  }
  return 'container';
}

const visual = (n) => {
  const { urls, grads } = bgLayers(n.s);
  return !!(color(n.s.backgroundColor) || urls.length || grads.length || borders(n.s).some(Boolean) || (n.s.boxShadow && n.s.boxShadow !== 'none') || paddings(n.s).some(Boolean) || n.overlays);
};

function collapse(n) {
  while (
    ['div', 'span', 'main'].includes(n.tag) && n.children.length === 1 && !n.raw && n.html === undefined && !n.icon &&
    !visual(n) && !n.children[0].virtual && Math.abs(n.children[0].rect.w - n.rect.w) < 3
  ) n = n.children[0];
  return n;
}

/* ================= header / footer detection ================= */
function isChrome(n, ctx) {
  const pageH = ctx.pageH;
  const tag = n.tag, key = `${n.cls} ${n.id}`;
  if (tag === 'footer' || n.role === 'contentinfo') return 'footer';
  if ((tag === 'header' || n.role === 'banner') && n.rect.h < 400) return 'header';
  if (tag === 'nav') return 'header';
  if (/(^|[\s_-])(site-?)?footer($|[\s_-])/i.test(key) && n.rect.y > pageH * 0.6) return 'footer';
  if (/(^|[\s_-])(site-?)?(header|topbar|top-bar|navbar|masthead)($|[\s_-])/i.test(key) && n.rect.y < 160 && n.rect.h < 350) return 'header';
  if (n.rect.y + n.rect.h <= 220 && !hasTag(n, /^h[1-3]$/)) return 'header';
  if (n.rect.y > pageH * 0.6 && n.rect.h < 1200 && /©|all rights reserved|copyright/i.test(textOf(n))) return 'footer';
  return null;
}

function flattenTop(nodes, ctx) {
  const out = [];
  for (const n of nodes) {
    if (ctx.skipChrome) {
      const kind = isChrome(n, ctx);
      if (kind) { ctx.stats.removed.push(kind); continue; }
    }
    const wrapper = ['div', 'main', 'section', 'article'].includes(n.tag) && n.children.length && !n.raw && n.html === undefined &&
      !visual(n) && n.rect.w >= ctx.vw - 2 && layoutDir(n) === 'column';
    if (wrapper) out.push(...flattenTop(n.children, ctx));
    else out.push(n);
  }
  return out;
}

/* ================= responsive cascade ================= */
const rsOf = (n, ctx) => {
  const id = n.cid ?? n.rsFrom;
  return {
    tablet: id != null && ctx.maps.tablet ? ctx.maps.tablet.get(id) : undefined,
    mobile: id != null && ctx.maps.mobile ? ctx.maps.mobile.get(id) : undefined,
  };
};
function steps(n, rs) {
  const out = [];
  let prev = n;
  for (const bp of BPS) {
    const node = rs[bp];
    if (node) { out.push({ bp, node, prev }); prev = node; }
  }
  return out;
}

function typo(n, rs) {
  const s = n.s;
  const t = { typography_typography: 'custom' };
  const f = firstFont(s.fontFamily);
  if (f) t.typography_font_family = f;
  t.typography_font_size = px(num(s.fontSize));
  t.typography_font_weight = String(s.fontWeight);
  if (s.lineHeight !== 'normal' && num(s.lineHeight)) t.typography_line_height = px(num(s.lineHeight));
  if (s.letterSpacing !== 'normal' && num(s.letterSpacing)) t.typography_letter_spacing = px(num(s.letterSpacing));
  if (['uppercase', 'lowercase', 'capitalize'].includes(s.textTransform)) t.typography_text_transform = s.textTransform;
  if (s.fontStyle === 'italic') t.typography_font_style = 'italic';
  for (const { bp, node, prev } of steps(n, rs)) {
    if (node.s.fontSize !== prev.s.fontSize) t[`typography_font_size_${bp}`] = px(num(node.s.fontSize));
    if (node.s.lineHeight !== prev.s.lineHeight && node.s.lineHeight !== 'normal') t[`typography_line_height_${bp}`] = px(num(node.s.lineHeight));
    if (node.s.letterSpacing !== prev.s.letterSpacing && node.s.letterSpacing !== 'normal') t[`typography_letter_spacing_${bp}`] = px(num(node.s.letterSpacing));
  }
  return t;
}
function alignSet(n, rs) {
  const o = { align: align(n.s) };
  for (const { bp, node, prev } of steps(n, rs)) if (align(node.s) !== align(prev.s)) o[`align_${bp}`] = align(node.s);
  return o;
}

/* ================= placement inside parent (width / align) ================= */
function place(el, n, rs, info, isC) {
  const set = el.settings, r = n.rect, kind = el.widgetType;
  const rowP = info.pDir.desktop.startsWith('row');
  const media = ['svg', 'video', 'canvas', 'iframe', 'audio', 'object', 'embed'].includes(n.tag);
  const widgetOk = ['heading', 'text-editor', 'image'].includes(kind) || (kind === 'html' && !media);
  const eligible = isC || widgetOk;
  const wKey = isC ? 'width' : '_element_custom_width';
  const setW = (suffix, w) => {
    set[wKey + suffix] = pct(safe(w));
    if (!isC) set['_element_width' + suffix] = 'initial';
  };
  const inD = info.inner.desktop;
  const w0 = Math.min(100, (r.w / inD) * 100);
  let cur = 100;

  let needD = false;
  if (rowP) needD = eligible;
  else if (r.w < inD - 3) needD = isC || (['heading', 'text-editor'].includes(kind) && n.s.maxWidth !== 'none');
  if (needD && eligible) { setW('', w0); cur = w0; }

  if (kind === 'image' && rowP) { set.width = pct(100); delete set.width_tablet; delete set.width_mobile; }
  if (rowP) set._flex_size = 'shrink';

  if (!rowP && r.w < inD - 3) {
    const left = r.x - info.innerX;
    const right = inD - left - r.w;
    set._flex_align_self = Math.abs(left - right) < 6 ? 'center' : left < right ? 'flex-start' : 'flex-end';
  }

  for (const { bp, node } of steps(n, rs)) {
    const inn = info.inner[bp];
    if (!inn) continue;
    const w = Math.min(100, (node.rect.w / inn) * 100);
    if (eligible && Math.abs(w - cur) > 1.5) { setW('_' + bp, w); cur = w; }
  }
}

/* ================= widgets ================= */
async function buildWidget(kind, n, rs, ctx) {
  const s = n.s;
  switch (kind) {
    case 'heading':
      ctx.stats.widgets++;
      return widget('heading', {
        title: n.html,
        header_size: /^h[1-6]$/.test(n.tag) ? n.tag : 'div',
        ...alignSet(n, rs),
        title_color: color(s.color),
        ...typo(n, rs),
      });
    case 'text': {
      ctx.stats.widgets++;
      let editor;
      if (n.wrapHtml) editor = n.wrapHtml;
      else if (n.tag === 'a' && n.href) editor = `<p><a href="${n.href}" style="color:inherit;text-decoration:inherit">${n.html}</a></p>`;
      else editor = `<p>${n.html}</p>`;
      return widget('text-editor', { editor, text_color: color(s.color), ...alignSet(n, rs), ...typo(n, rs) });
    }
    case 'button': {
      ctx.stats.widgets++;
      let [pt, pr, pb, pl] = paddings(s);
      if (!(pt + pr + pb + pl)) [pt, pr, pb, pl] = [12, 24, 12, 24];
      const b = borders(s);
      const set = {
        text: plain(n.html),
        link: { url: n.href || '#', is_external: '', nofollow: '', custom_attributes: '' },
        button_text_color: color(s.color),
        background_color: color(s.backgroundColor),
        text_padding: dim(pt, pr, pb, pl),
        border_radius: dim(...radii(s, n.rect)),
        ...typo(n, rs),
      };
      if (b.some(Boolean)) { set.border_border = 'solid'; set.border_width = dim(...b); set.border_color = color(s.borderTopColor); }
      return widget('button', set);
    }
    case 'icon': {
      ctx.stats.widgets++;
      const lib = n.icon.startsWith('fab') ? 'fa-brands' : n.icon.startsWith('far') ? 'fa-regular' : 'fa-solid';
      return widget('icon', {
        selected_icon: { value: n.icon, library: lib },
        primary_color: color(s.color),
        size: px(Math.max(num(s.fontSize), 8)),
      });
    }
    case 'image': {
      if (!n.src) return null;
      ctx.stats.widgets++;
      const set = { image: { url: n.src, id: '', alt: n.alt || '' }, image_size: 'full', width: px(n.rect.w) };
      for (const { bp, node, prev } of steps(n, rs)) {
        if (Math.abs(node.rect.w - prev.rect.w) > 3) set[`width_${bp}`] = px(node.rect.w);
      }
      const ratioOff = n.nw && n.nh ? Math.abs(n.nw / n.nh / (n.rect.w / n.rect.h) - 1) > 0.04 : false;
      if (s.objectFit === 'cover' || ratioOff) {
        set.height = px(n.rect.h);
        set['object-fit'] = 'cover';
        for (const { bp, node, prev } of steps(n, rs)) if (Math.abs(node.rect.h - prev.rect.h) > 3) set[`height_${bp}`] = px(node.rect.h);
      }
      const rad = radii(s, n.rect);
      if (rad.some(Boolean)) set.image_border_radius = dim(...rad);
      return widget('image', set);
    }
    case 'html': {
      if (ctx.refine && n.pattern) {
        const native = await ctx.refine(n).catch(() => null);
        if (native) { ctx.stats.nativeByGemini++; ctx.stats.widgets++; return native; }
      }
      ctx.stats.htmlFallbacks++;
      ctx.stats.widgets++;
      return widget('html', { html: n.html });
    }
  }
  return null;
}

/* ================= container ================= */
const JUSTIFY = { 'flex-start': 'flex-start', start: 'flex-start', center: 'center', 'flex-end': 'flex-end', end: 'flex-end', 'space-between': 'space-between', 'space-around': 'space-around', 'space-evenly': 'space-evenly' };
const ALIGNI = { 'flex-start': 'flex-start', start: 'flex-start', center: 'center', 'flex-end': 'flex-end', end: 'flex-end', stretch: 'stretch', baseline: 'flex-start' };
const SEMANTIC = new Set(['header', 'footer', 'main', 'article', 'aside', 'nav', 'section']);

const innerOf = (node) => {
  const pad = paddings(node.s), bw = borders(node.s);
  return Math.max(1, node.rect.w - pad[1] - pad[3] - bw[1] - bw[3]);
};

async function buildContainer(n, rs, ctx, info, hid) {
  ctx.stats.containers++;
  const s = n.s;
  const pad = paddings(s), bw = borders(s);
  const st = steps(n, rs);

  // overlay layers (absolute cover divs + ::before/::after) ko flow se hata ke overlay bana do
  const layers = [...(n.overlays || [])];
  const flowKids = [];
  for (const c of n.children) {
    const bi = c.s.backgroundImage || 'none';
    const covers = c.rect.w >= n.rect.w * 0.9 && c.rect.h >= n.rect.h * 0.9;
    if (c.s.position === 'absolute' && !hasContent(c) && covers && (color(c.s.backgroundColor) || (bi !== 'none' && !bi.includes('url(')))) {
      layers.push({ backgroundColor: c.s.backgroundColor, backgroundImage: c.s.backgroundImage, opacity: c.s.opacity });
    } else flowKids.push(c);
  }

  // direction / inner width per breakpoint
  const dirs = { desktop: layoutDir(n) };
  const inner = { desktop: innerOf(n) };
  let pd = dirs.desktop, pi = inner.desktop;
  for (const bp of BPS) {
    const node = rs[bp];
    if (node) { pd = layoutDir(node); pi = innerOf(node); }
    dirs[bp] = pd;
    inner[bp] = node ? pi : null;
  }
  const dir = dirs.desktop;
  const row = dir.startsWith('row');
  const isFlex = s.display.includes('flex'), isGrid = s.display.includes('grid');

  const set = { content_width: 'full', flex_direction: dir };
  let prevDir = dir;
  for (const bp of BPS) {
    if (rs[bp] && dirs[bp] !== prevDir) set[`flex_direction_${bp}`] = dirs[bp];
    if (rs[bp]) prevDir = dirs[bp];
  }
  if ((isFlex || isGrid) && JUSTIFY[s.justifyContent]) set.justify_content = JUSTIFY[s.justifyContent];
  if ((isFlex || isGrid) && ALIGNI[s.alignItems]) set.align_items = ALIGNI[s.alignItems];
  if (row && (s.flexWrap === 'wrap' || isGrid || !isFlex)) set.flex_wrap = 'wrap';

  // children
  const childInfo = { top: false, pDir: dirs, inner, innerX: n.rect.x + bw[3] + pad[3], hid };
  const kidNodes = [], kidEls = [];
  for (const c of flowKids) {
    const el = await toElement(c, ctx, childInfo);
    if (el) { kidEls.push(el); kidNodes.push(c); }
  }

  // gaps
  let cg = num(s.columnGap), rg = num(s.rowGap);
  const cssGap = isFlex || isGrid;
  if (kidEls.length > 1 && !cssGap) {
    const gaps = [];
    for (let i = 1; i < kidNodes.length; i++) {
      const a = kidNodes[i - 1].rect, b = kidNodes[i].rect;
      if (row) gaps.push(Math.abs(b.y - a.y) < 6 ? Math.max(0, b.x - (a.x + a.w)) : null);
      else gaps.push(Math.max(0, b.y - (a.y + a.h)));
    }
    const med = median(gaps.filter((g) => g !== null));
    if (row) cg = med;
    else {
      rg = med;
      gaps.forEach((g, i) => {
        if (g !== null && g - med > 4) {
          const el = kidEls[i + 1];
          el.settings[el.elType === 'container' ? 'margin' : '_margin'] = dim(g - med, 0, 0, 0);
        }
      });
    }
  }
  set.flex_gap = { column: String(r2(cg)), row: String(r2(rg)), isLinked: cg === rg, unit: 'px', size: r2(cg) };
  if (cssGap) {
    for (const { bp, node, prev } of st) {
      const mc = num(node.s.columnGap), mr = num(node.s.rowGap);
      if (mc !== num(prev.s.columnGap) || mr !== num(prev.s.rowGap)) set[`flex_gap_${bp}`] = { column: String(r2(mc)), row: String(r2(mr)), isLinked: mc === mr, unit: 'px', size: r2(mc) };
    }
  }

  // background
  const bg = color(s.backgroundColor);
  const { urls, grads } = bgLayers(s);
  const img = urls[0];
  let overlay = layers.length ? overlaySet(layers[0]) : null;
  if (img) {
    set.background_background = 'classic';
    if (bg) set.background_color = bg;
    set.background_image = { url: img, id: '' };
    const pos = (s.backgroundPosition || '50% 50%').split(' ');
    const xm = { '0%': 'left', '50%': 'center', '100%': 'right', left: 'left', center: 'center', right: 'right' };
    const ym = { '0%': 'top', '50%': 'center', '100%': 'bottom', top: 'top', center: 'center', bottom: 'bottom' };
    set.background_position = `${ym[pos[1]] || 'center'} ${xm[pos[0]] || 'center'}`;
    set.background_repeat = (s.backgroundRepeat || '').startsWith('no') ? 'no-repeat' : 'repeat';
    set.background_size = s.backgroundSize === 'contain' ? 'contain' : s.backgroundSize === 'cover' ? 'cover' : 'auto';
    if (!overlay && grads.length) overlay = overlaySet({ backgroundImage: grads[0], opacity: 1 });
  } else if (grads.length) {
    const g = parseGradient(grads[0]);
    if (g) Object.assign(set, gradSet('background', g));
  } else if (bg) {
    set.background_background = 'classic';
    set.background_color = bg;
  }
  if (overlay) {
    if (img || bg) Object.assign(set, overlay);
    else if (overlay.background_overlay_color) { set.background_background = 'classic'; set.background_color = overlay.background_overlay_color; }
  }

  if (bw.some(Boolean)) {
    set.border_border = 'solid';
    set.border_width = dim(...bw);
    set.border_color = color(s.borderTopColor) || color(s.borderBottomColor);
  }
  const rad = radii(s, n.rect);
  if (rad.some(Boolean)) set.border_radius = dim(...rad);
  const sh = /(rgba?\([^)]+\)|#[0-9a-f]{3,8})\s+(-?[\d.]+)px\s+(-?[\d.]+)px\s+(-?[\d.]+)px(?:\s+(-?[\d.]+)px)?/i.exec(s.boxShadow || '');
  if (sh && !/inset/.test(s.boxShadow)) {
    set.box_shadow_box_shadow_type = 'yes';
    set.box_shadow_box_shadow = { horizontal: num(sh[2]), vertical: num(sh[3]), blur: num(sh[4]), spread: num(sh[5]), color: color(sh[1]) || sh[1] };
  }
  set.padding = dim(...pad); // 0 bhi explicit: Elementor ka default 10px override
  for (const { bp, node, prev } of st) {
    const p = paddings(node.s), pp = paddings(prev.s);
    if (p.some((v, i) => v !== pp[i])) set[`padding_${bp}`] = dim(...p);
    if (node.s.minHeight !== prev.s.minHeight && num(node.s.minHeight)) set[`min_height_${bp}`] = px(num(node.s.minHeight));
  }
  if (!kidEls.length) set.min_height = px(n.rect.h);
  else if (num(s.minHeight) > 0) set.min_height = px(num(s.minHeight));
  else if (img && info.top) set.min_height = px(n.rect.h);

  if (SEMANTIC.has(n.tag)) set.html_tag = n.tag;
  if (n.tag === 'a' && n.href) {
    set.html_tag = 'a';
    set.link = { url: n.href, is_external: '', nofollow: '', custom_attributes: '' };
  }
  return { id: uid(), elType: 'container', isInner: !info.top, settings: clean(set), elements: kidEls };
}

/* ================= dispatcher ================= */
// bg/border/padding wala text element (pill, badge, card-title) -> container + andar plain text widget
function wrapStyledText(n) {
  if (n.html === undefined || n.virtual || n.btn || n.tag === 'button' || n.wrapHtml) return n;
  const k = classify(n);
  if ((k !== 'text' && k !== 'heading') || !visual(n)) return n;
  const pad = paddings(n.s), bw = borders(n.s);
  const bare = {
    ...n.s,
    backgroundColor: 'rgba(0, 0, 0, 0)', backgroundImage: 'none', boxShadow: 'none',
    paddingTop: '0px', paddingRight: '0px', paddingBottom: '0px', paddingLeft: '0px',
    borderTopWidth: '0px', borderRightWidth: '0px', borderBottomWidth: '0px', borderLeftWidth: '0px',
    borderTopLeftRadius: '0px', borderTopRightRadius: '0px', borderBottomRightRadius: '0px', borderBottomLeftRadius: '0px',
  };
  const child = {
    ...n, cid: null, rsFrom: n.cid, s: bare, tag: /^h[1-6]$/.test(n.tag) ? n.tag : 'p', href: undefined, overlays: undefined,
    rect: { x: n.rect.x + bw[3] + pad[3], y: n.rect.y + bw[0] + pad[0], w: Math.max(1, n.rect.w - pad[1] - pad[3] - bw[1] - bw[3]), h: Math.max(1, n.rect.h - pad[0] - pad[2] - bw[0] - bw[2]) },
    children: [],
  };
  return { ...n, html: undefined, children: [child], tag: n.tag === 'a' ? 'a' : 'div' };
}

async function toElement(n, ctx, info) {
  if (n.s.position === 'fixed') return null; // sticky bars, chat widgets, cookie banners
  if (n.s.position === 'absolute' && !hasContent(n)) return null; // decorative overlays
  n = collapse(n);
  n = wrapStyledText(n);
  const rs = rsOf(n, ctx);
  const kind = classify(n);

  // kis breakpoint pe ye element hidden hai
  const hid = { tablet: info.hid.tablet, mobile: info.hid.mobile };
  const hideNow = {};
  for (const bp of BPS) {
    if (!info.hid[bp] && ctx.maps[bp] && n.cid != null && !rs[bp]) { hid[bp] = true; hideNow[bp] = true; }
  }

  const el = kind === 'container' ? await buildContainer(n, rs, ctx, info, hid) : await buildWidget(kind, n, rs, ctx);
  if (!el) return null;
  for (const bp of Object.keys(hideNow)) el.settings[`hide_${bp}`] = `hidden-${bp}`;
  if (!info.top) place(el, n, rs, info, el.elType === 'container');
  return el;
}

/* ================= public API ================= */
export async function convertPage(extracted, { refine, skipChrome = true } = {}) {
  const warnings = [];
  const { desktop } = extracted;
  const maps = { tablet: null, mobile: null };

  let total = 0;
  walkTree(desktop, (n) => { if (n.cid != null) total++; });
  for (const bp of BPS) {
    const tree = extracted[bp];
    if (!tree) { warnings.push(`${bp} layout extract nahi hua, uski responsive settings skip.`); continue; }
    const map = new Map();
    indexTree(tree, map);
    let matched = 0;
    walkTree(desktop, (n) => { if (n.cid != null && map.has(n.cid)) matched++; });
    if (matched / Math.max(1, total) < 0.4) warnings.push(`${bp} layout desktop se match nahi hua (site alag HTML deti hai), uski responsive settings skip.`);
    else maps[bp] = map;
  }

  const ctx = {
    maps, refine, skipChrome,
    vw: desktop.rect.w,
    pageH: desktop.rect.h,
    stats: { containers: 0, widgets: 0, htmlFallbacks: 0, nativeByGemini: 0, removed: [] },
  };
  const tops = flattenTop(desktop.children, ctx);
  const vwOf = (bp) => (extracted[bp] ? extracted[bp].rect.w : null);
  const info = {
    top: true,
    pDir: { desktop: 'column', tablet: 'column', mobile: 'column' },
    inner: { desktop: ctx.vw, tablet: vwOf('tablet'), mobile: vwOf('mobile') },
    innerX: 0,
    hid: { tablet: false, mobile: false },
  };

  const raw = [];
  for (const n of tops) {
    const el = await toElement(n, ctx, info);
    if (el) raw.push(el);
  }
  const { elements, errors } = sanitizeElements(raw, false);
  warnings.push(...errors);
  if (ctx.stats.removed.length) warnings.push(`Header/footer hata diye gaye: ${ctx.stats.removed.length} block.`);
  if (ctx.stats.htmlFallbacks) warnings.push(`${ctx.stats.htmlFallbacks} block(s) HTML widget me gaye (svg/form/table etc.) - ye edit me limited honge.`);
  if (!elements.length) warnings.push('Koi content nahi mila. Page JS se load hota ho ya bot-protected ho sakta hai.');
  return { content: elements, stats: ctx.stats, warnings };
}
