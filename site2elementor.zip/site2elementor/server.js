import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import dns from 'node:dns/promises';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { extractPage } from './src/extract.js';
import { convertPage } from './src/convert.js';
import { refineNode, screenshotToElementor } from './src/gemini.js';
import { buildTemplate } from './src/validate.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

/* ---- basic SSRF guard: sirf public http(s) URLs ---- */
const isPrivateIp = (ip) =>
  /^(10\.|127\.|0\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip) ||
  ip === '::1' || /^f[cd]/i.test(ip) || /^fe80/i.test(ip);

async function assertPublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('URL galat hai'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Sirf http/https URL allowed hai');
  const host = u.hostname.replace(/^\[|\]$/g, '');
  const addrs = net.isIP(host) ? [{ address: host }] : await dns.lookup(host, { all: true });
  if (addrs.some((a) => isPrivateIp(a.address))) throw new Error('Private/local address allowed nahi hai');
  return u.href;
}

/* ---- simple concurrency limit (Playwright heavy hota hai) ---- */
let active = 0;
const MAX = 2;
const guard = (fn) => async (req, res) => {
  if (active >= MAX) return res.status(429).json({ error: 'Server busy hai, thodi der baad try karo.' });
  active++;
  try { await fn(req, res); }
  catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
  finally { active--; }
};

app.post('/api/convert/url', guard(async (req, res) => {
  const url = await assertPublicUrl(req.body?.url);
  const refine = process.env.USE_GEMINI_REFINE === 'true' && process.env.GEMINI_API_KEY ? refineNode : null;
  const extracted = await extractPage(url, { patterns: !!refine });
  const { content, stats, warnings } = await convertPage(extracted, { refine, skipChrome: req.body?.skipChrome !== false });
  res.json({ title: extracted.title, template: buildTemplate(content, extracted.title || 'Imported Page'), stats, warnings });
}));

app.post('/api/convert/screenshot', upload.single('image'), guard(async (req, res) => {
  if (!req.file) throw new Error('image upload karo');
  if (!/^image\/(png|jpe?g|webp)$/.test(req.file.mimetype)) throw new Error('Sirf png/jpg/webp allowed hai');
  const { content, warnings } = await screenshotToElementor(req.file.buffer, req.file.mimetype);
  res.json({ title: 'Screenshot Import', template: buildTemplate(content, 'Screenshot Import'), stats: {}, warnings });
}));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`http://localhost:${port}`));
